#include <iostream> // Library for input and output operations

#include <cstdlib> // Library for generating random numbers

#include <ctime>   // Library for working with time

using namespace std; // Allows usage of entities from the standard namespace

// Function to print the choices made by the player and the computer

void printChoices(char playerChoice, char computerChoice) {
    
    // Display the player's choice

    cout << "You chose: " << playerChoice << endl;

    // Display the computer's choice

    cout << "Computer chose: " << computerChoice << endl;
}

// Function to determine the winner of a single round
// 
// Returns 1 if the player wins, -1 if the computer wins, 0 for a tie

int determineRoundWinner(char playerChoice, char computerChoice) {

    // Check for a tie

    if (playerChoice == computerChoice) {

        return 0; // Indicates a tie
    }
    // Check all possible winning scenarios for the player

    else if ((playerChoice == 'r' && computerChoice == 's') ||
        (playerChoice == 'p' && computerChoice == 'r') ||

        (playerChoice == 's' && computerChoice == 'p')) {

        return 1; // Indicates player wins
    }
    else {
        return -1; // Indicates computer wins
    }
}

int main() {
    srand(time(NULL)); // Seed the random number generator with the current time

    int numRounds; // Variable to store the number of rounds to be played

    cout << "How many rounds do you want to play? ";

    cin >> numRounds; // Read the number of rounds from the user

    int playerScore = 0;    // Variable to store the player's score

    int computerScore = 0;  // Variable to store the computer's score

    // Loop through each round

    for (int round = 1; round <= numRounds; ++round) {

        cout << "\nRound " << round << endl; // Display the current round number

        // Prompt the player to enter their choice

        char playerChoice;

        cout << "Enter your choice (r for Rock, p for Paper, s for Scissors): ";

        cin >> playerChoice;

        // Generate the computer's choice randomly

        char choices[] = { 'r', 'p', 's' };

        char computerChoice = choices[rand() % 3];

        // Print out the choices made by the player and the computer

        printChoices(playerChoice, computerChoice);

        // Determine the winner of the round

        int roundResult = determineRoundWinner(playerChoice, computerChoice);

        // Update scores based on the round result

        if (roundResult == 1) {

            cout << "You win this round!" << endl;

            playerScore++; // Increment player's score
        }
        else if (roundResult == -1) {

            cout << "Computer wins this round!" << endl;

            computerScore++; // Increment computer's score
        }
        else {

            cout << "It's a tie!" << endl;
        }
    }

    // Display overall results

    cout << "\nGame over! Results:" << endl;

    cout << "Player score: " << playerScore << endl;

    cout << "Computer score: " << computerScore << endl;


    // Determine the winner of the game

    if (playerScore > computerScore) {

        cout << "Congratulations! You win the game!" << endl;
    }
    else if (computerScore > playerScore) {

        cout << "Computer wins the game. Better luck next time!" << endl;
    }
    else {

        cout << "It's a tie game!" << endl;
    }

    return 0; // Return 0 to indicate successful execution

}







